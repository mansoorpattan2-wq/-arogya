import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Pill, 
  Calendar, 
  ChevronRight, 
  Activity, 
  Clock,
  AlertCircle,
  ArrowUpRight,
  Stethoscope,
  MessageSquare,
  FileText,
  Plus,
  Sparkles,
  RefreshCw,
  Volume2
} from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Dashboard() {
  const [medicines, setMedicines] = useState<any[]>([]);
  const [appointments, setAppointments] = useState<any[]>([]);

  useEffect(() => {
    fetch('/api/medicines').then(res => res.json()).then(setMedicines);
    fetch('/api/appointments').then(res => res.json()).then(setAppointments);
  }, []);

  const nextMedicine = medicines[0];
  const nextAppointment = appointments[0];

  return (
    <div className="space-y-12 pb-20">
      {/* Hero Section */}
      <header className="relative py-12 px-10 bg-slate-900 rounded-[3rem] text-white overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-1/2 h-full bg-emerald-500/10 blur-[120px] rounded-full -translate-y-1/2 translate-x-1/4" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-8">
          <div className="space-y-4">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-emerald-500/20 border border-emerald-500/30 rounded-full">
              <Sparkles size={14} className="text-emerald-400" />
              <span className="text-[10px] font-black uppercase tracking-[0.2em] text-emerald-400">Health Status: Optimal</span>
            </div>
            <h1 className="text-5xl font-black tracking-tight leading-none">
              Your Health, <br />
              <span className="text-emerald-400 italic serif">Perfectly Synced.</span>
            </h1>
            <p className="text-slate-400 font-medium max-w-md">
              Arogya Mantra is monitoring your vitals and schedule in real-time. You have 2 tasks remaining today.
            </p>
          </div>
          <div className="flex gap-4">
            <div className="p-6 bg-white/5 backdrop-blur-xl border border-white/10 rounded-[2rem] text-center min-w-[120px]">
              <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Daily Goal</p>
              <p className="text-3xl font-black">85%</p>
            </div>
            <div className="p-6 bg-emerald-500 rounded-[2rem] text-center min-w-[120px] shadow-lg shadow-emerald-500/20">
              <p className="text-[10px] font-black text-emerald-100 uppercase tracking-widest mb-2">Streak</p>
              <p className="text-3xl font-black">12d</p>
            </div>
          </div>
        </div>
      </header>

      {/* Vitals Section */}
      <section className="space-y-6">
        <div className="flex items-center justify-between px-2">
          <h2 className="text-xs font-black text-slate-400 uppercase tracking-[0.3em]">Live Biometrics</h2>
          <div className="flex items-center gap-2 text-emerald-600 font-bold text-xs">
            <RefreshCw size={12} className="animate-spin-slow" />
            Syncing with Wearable
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            { label: 'Heart Rate', value: '72', unit: 'bpm', color: 'rose', icon: Activity },
            { label: 'Blood Pressure', value: '120/80', unit: 'mmHg', color: 'blue', icon: Activity },
            { label: 'Blood Sugar', value: '95', unit: 'mg/dL', color: 'amber', icon: Activity },
          ].map((stat, i) => (
            <motion.div 
              key={i}
              whileHover={{ y: -8, scale: 1.02 }}
              className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm hover:shadow-2xl transition-all duration-500 group"
            >
              <div className={`w-14 h-14 bg-${stat.color}-50 rounded-2xl flex items-center justify-center text-${stat.color}-500 mb-6 group-hover:scale-110 transition-transform`}>
                <stat.icon size={28} />
              </div>
              <p className="text-xs font-black text-slate-400 uppercase tracking-widest mb-1">{stat.label}</p>
              <div className="flex items-baseline gap-2">
                <h3 className="text-4xl font-black text-slate-900 tracking-tight">{stat.value}</h3>
                <span className="text-sm font-bold text-slate-400">{stat.unit}</span>
              </div>
              <div className="mt-6 h-1 w-full bg-slate-50 rounded-full overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: '70%' }}
                  className={`h-full bg-${stat.color}-500`}
                />
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
        {/* Next Medicine */}
        <section className="space-y-6">
          <div className="flex items-center justify-between px-2">
            <h2 className="text-xs font-black text-slate-400 uppercase tracking-[0.3em]">Upcoming Intake</h2>
            <Link to="/medicines" className="text-xs font-black text-emerald-600 hover:underline tracking-widest">MANAGE ALL</Link>
          </div>
          
          {nextMedicine ? (
            <motion.div 
              whileHover={{ scale: 1.01 }}
              className="bg-white rounded-[3rem] p-10 border border-slate-100 shadow-xl relative overflow-hidden group"
            >
              <div className="absolute top-0 right-0 p-12 text-slate-50 opacity-50 group-hover:text-emerald-50 transition-colors">
                <Pill size={160} />
              </div>
              <div className="relative z-10 space-y-8">
                <div className="flex items-center gap-4">
                  <div className="px-5 py-2 bg-emerald-600 text-white rounded-full text-sm font-black shadow-lg shadow-emerald-200">
                    {nextMedicine.time}
                  </div>
                  <div className="flex items-center gap-2 text-slate-400 font-bold text-sm">
                    <Volume2 size={16} />
                    {(nextMedicine.reminder_sound || 'gentle-chime').replace('-', ' ')}
                  </div>
                </div>
                <div>
                  <h3 className="text-4xl font-black text-slate-900 mb-2">{nextMedicine.name}</h3>
                  <p className="text-slate-500 font-bold text-lg">{nextMedicine.dosage} • {nextMedicine.frequency}</p>
                </div>
                <button className="w-full py-5 bg-slate-900 text-white rounded-[1.5rem] font-black text-lg hover:bg-emerald-600 transition-all shadow-2xl active:scale-95">
                  Mark as Taken
                </button>
              </div>
            </motion.div>
          ) : (
            <div className="bg-slate-100 rounded-[3rem] p-16 text-center border-2 border-dashed border-slate-200">
              <Pill className="mx-auto text-slate-300 mb-6" size={64} />
              <p className="text-slate-500 font-black text-xl">All caught up!</p>
              <Link to="/medicines" className="mt-4 inline-block text-emerald-600 font-black uppercase tracking-widest text-sm">Add New Schedule</Link>
            </div>
          )}
        </section>

        {/* Next Appointment */}
        <section className="space-y-6">
          <div className="flex items-center justify-between px-2">
            <h2 className="text-xs font-black text-slate-400 uppercase tracking-[0.3em]">Next Consultation</h2>
            <Link to="/appointments" className="text-xs font-black text-emerald-600 hover:underline tracking-widest">VIEW HISTORY</Link>
          </div>

          {nextAppointment ? (
            <div className="bg-white rounded-[3rem] p-10 border border-slate-100 shadow-xl space-y-10">
              <div className="flex items-start justify-between">
                <div className="flex gap-6">
                  <div className="w-20 h-20 bg-blue-50 rounded-[2rem] flex items-center justify-center text-blue-600 shadow-inner">
                    <Stethoscope size={36} />
                  </div>
                  <div>
                    <h3 className="font-black text-slate-900 text-2xl mb-1">{nextAppointment.doctor_name}</h3>
                    <p className="text-slate-500 font-bold">{nextAppointment.hospital_name}</p>
                    <div className="mt-2 inline-flex items-center gap-2 px-3 py-1 bg-emerald-50 text-emerald-600 text-[10px] font-black rounded-full uppercase tracking-widest">
                      Confirmed
                    </div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div className="bg-slate-50 rounded-[2rem] p-6 flex flex-col gap-2">
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Scheduled Date</span>
                  <div className="flex items-center gap-3 font-black text-slate-900">
                    <Calendar size={20} className="text-emerald-500" />
                    {nextAppointment.appointment_date}
                  </div>
                </div>
                <div className="bg-slate-50 rounded-[2rem] p-6 flex flex-col gap-2">
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Appointment Time</span>
                  <div className="flex items-center gap-3 font-black text-slate-900">
                    <Clock size={20} className="text-blue-500" />
                    {nextAppointment.appointment_time}
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-[3rem] p-16 text-center border-2 border-dashed border-slate-200">
              <Calendar className="mx-auto text-slate-300 mb-6" size={64} />
              <p className="text-slate-500 font-black text-xl">No appointments</p>
              <Link to="/doctors" className="mt-4 inline-block text-emerald-600 font-black uppercase tracking-widest text-sm">Book Specialist</Link>
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
