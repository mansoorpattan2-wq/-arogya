import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { FileText, Plus, Calendar, User, Trash2, ExternalLink, Download, ShieldCheck } from 'lucide-react';

export default function PrescriptionVault() {
  const [prescriptions, setPrescriptions] = useState<any[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [newPrescription, setNewPrescription] = useState({
    doctor_name: '',
    date: new Date().toISOString().split('T')[0],
    notes: '',
    image_url: 'https://picsum.photos/seed/presc/800/1000'
  });

  useEffect(() => {
    fetch('/api/prescriptions').then(res => res.json()).then(setPrescriptions);
  }, []);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    await fetch('/api/prescriptions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newPrescription)
    });
    setShowAdd(false);
    fetch('/api/prescriptions').then(res => res.json()).then(setPrescriptions);
  };

  return (
    <div className="space-y-12 pb-20">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div className="space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-emerald-50 text-emerald-600 rounded-full">
            <ShieldCheck size={14} />
            <span className="text-[10px] font-black uppercase tracking-[0.2em]">End-to-End Encrypted</span>
          </div>
          <h1 className="text-5xl font-black text-slate-900 tracking-tight">Prescription Vault</h1>
          <p className="text-slate-500 font-medium max-w-xl">Your medical history, digitized and secured. Access your prescriptions anytime, anywhere.</p>
        </div>
        <button 
          onClick={() => setShowAdd(true)}
          className="flex items-center gap-3 px-8 py-4 bg-emerald-600 text-white rounded-2xl font-black shadow-xl shadow-emerald-200 hover:bg-emerald-700 transition-all active:scale-95"
        >
          <Plus size={24} />
          Upload Document
        </button>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {prescriptions.map((p) => (
          <motion.div 
            key={p.id}
            whileHover={{ y: -10 }}
            className="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm overflow-hidden group hover:shadow-2xl transition-all duration-500"
          >
            <div className="aspect-[3/4] bg-slate-100 relative overflow-hidden">
              <img 
                src={p.image_url} 
                alt="Prescription" 
                className="w-full h-full object-cover opacity-90 group-hover:opacity-100 group-hover:scale-105 transition-all duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-slate-900/20 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-500 flex flex-col justify-end p-8">
                <div className="space-y-4">
                  <div className="flex gap-3">
                    <button className="flex-1 py-3 bg-white text-slate-900 rounded-xl font-black text-sm flex items-center justify-center gap-2 hover:bg-emerald-50 transition-colors">
                      <Download size={18} />
                      Download
                    </button>
                    <button className="p-3 bg-white/20 backdrop-blur-xl text-white rounded-xl hover:bg-white/30 transition-colors">
                      <ExternalLink size={20} />
                    </button>
                  </div>
                </div>
              </div>
            </div>
            <div className="p-8 space-y-6">
              <div className="flex items-start justify-between">
                <div className="space-y-1">
                  <h3 className="text-xl font-black text-slate-900">{p.doctor_name}</h3>
                  <div className="flex items-center gap-2 text-slate-400 font-bold text-xs uppercase tracking-widest">
                    <Calendar size={14} className="text-emerald-500" />
                    <span>{p.date}</span>
                  </div>
                </div>
                <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center shadow-inner">
                  <FileText size={24} />
                </div>
              </div>
              {p.notes && (
                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
                  <p className="text-sm text-slate-500 font-medium italic leading-relaxed">"{p.notes}"</p>
                </div>
              )}
            </div>
          </motion.div>
        ))}

        {prescriptions.length === 0 && (
          <div className="col-span-full bg-white rounded-[3rem] p-24 text-center border-2 border-dashed border-slate-200">
            <div className="w-24 h-24 bg-slate-50 rounded-[2.5rem] flex items-center justify-center text-slate-200 mx-auto mb-8">
              <FileText size={48} />
            </div>
            <h3 className="text-2xl font-black text-slate-900 mb-3">Your Vault is Empty</h3>
            <p className="text-slate-500 mb-10 max-w-sm mx-auto font-medium">Keep your medical records organized. Upload your first prescription to get started.</p>
            <button 
              onClick={() => setShowAdd(true)}
              className="px-10 py-4 bg-emerald-600 text-white rounded-2xl font-black shadow-2xl shadow-emerald-200 hover:scale-105 transition-transform"
            >
              Upload First Document
            </button>
          </div>
        )}
      </div>

      {/* Add Modal */}
      <AnimatePresence>
        {showAdd && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAdd(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-md"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 40 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 40 }}
              className="relative w-full max-w-xl bg-white rounded-[3rem] shadow-2xl p-10 overflow-hidden"
            >
              <div className="absolute top-0 left-0 w-full h-2 bg-emerald-500" />
              <h2 className="text-3xl font-black text-slate-900 mb-8">Upload Document</h2>
              <form onSubmit={handleAdd} className="space-y-6">
                <div className="space-y-2">
                  <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Doctor / Clinic Name</label>
                  <input 
                    required
                    type="text"
                    value={newPrescription.doctor_name}
                    onChange={e => setNewPrescription({...newPrescription, doctor_name: e.target.value})}
                    placeholder="e.g. Dr. Sarah Smith"
                    className="w-full px-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 outline-none transition-all font-bold text-slate-900"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Date of Issue</label>
                  <input 
                    required
                    type="date"
                    value={newPrescription.date}
                    onChange={e => setNewPrescription({...newPrescription, date: e.target.value})}
                    className="w-full px-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 outline-none transition-all font-bold text-slate-900"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Notes (Optional)</label>
                  <textarea 
                    value={newPrescription.notes}
                    onChange={e => setNewPrescription({...newPrescription, notes: e.target.value})}
                    placeholder="e.g. Follow up in 2 weeks for blood test results"
                    className="w-full px-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 outline-none h-32 resize-none transition-all font-bold text-slate-900"
                  />
                </div>
                <div className="pt-6 flex gap-4">
                  <button 
                    type="button"
                    onClick={() => setShowAdd(false)}
                    className="flex-1 py-4 bg-slate-100 text-slate-600 rounded-2xl font-black hover:bg-slate-200 transition-colors"
                  >
                    Discard
                  </button>
                  <button 
                    type="submit"
                    className="flex-1 py-4 bg-emerald-600 text-white rounded-2xl font-black hover:bg-emerald-700 transition-all shadow-xl shadow-emerald-200"
                  >
                    Save to Vault
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
