import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Stethoscope, MapPin, Clock, Search, Star, ChevronRight, ShieldCheck } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function DoctorDirectory() {
  const [doctors, setDoctors] = useState<any[]>([]);
  const [search, setSearch] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    fetch('/api/doctors').then(res => res.json()).then(setDoctors);
  }, []);

  const filteredDoctors = doctors.filter(doc => 
    doc.name.toLowerCase().includes(search.toLowerCase()) ||
    doc.specialty.toLowerCase().includes(search.toLowerCase()) ||
    doc.hospital.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-12 pb-20">
      <header className="space-y-4">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-blue-50 text-blue-600 rounded-full">
          <Stethoscope size={14} className="animate-pulse" />
          <span className="text-[10px] font-black uppercase tracking-[0.2em]">Verified Network</span>
        </div>
        <h1 className="text-5xl font-black text-slate-900 tracking-tight">Find Specialists</h1>
        <p className="text-slate-500 font-medium max-w-2xl">Access our network of top-rated medical professionals. Book instant consultations and skip the queue.</p>
      </header>

      <div className="relative group">
        <div className="absolute inset-0 bg-emerald-500/5 blur-2xl rounded-3xl group-focus-within:bg-emerald-500/10 transition-all" />
        <div className="relative flex items-center">
          <Search className="absolute left-6 text-slate-400 group-focus-within:text-emerald-500 transition-colors" size={24} />
          <input 
            type="text"
            placeholder="Search by name, specialty, or hospital..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full pl-16 pr-8 py-6 bg-white border border-slate-100 rounded-[2rem] shadow-sm focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 outline-none transition-all text-lg font-bold text-slate-900"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {filteredDoctors.map((doc) => (
          <motion.div 
            key={doc.id}
            whileHover={{ y: -10, scale: 1.01 }}
            className="bg-white rounded-[3rem] border border-slate-100 shadow-sm hover:shadow-2xl transition-all duration-500 overflow-hidden group"
          >
            <div className="p-8 space-y-8">
              <div className="flex items-start justify-between">
                <div className="flex gap-6">
                  <div className="w-24 h-24 bg-slate-100 rounded-[2rem] overflow-hidden relative shadow-inner">
                    <img 
                      src={`https://picsum.photos/seed/${doc.id}/200/200`} 
                      alt={doc.name} 
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute bottom-2 right-2">
                      <div className="w-6 h-6 bg-emerald-500 rounded-full border-2 border-white flex items-center justify-center">
                        <ShieldCheck size={12} className="text-white fill-white" />
                      </div>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <h3 className="text-2xl font-black text-slate-900 group-hover:text-emerald-600 transition-colors">{doc.name}</h3>
                    <p className="text-emerald-600 font-black text-sm uppercase tracking-widest">{doc.specialty}</p>
                    <div className="flex items-center gap-2 pt-1">
                      <div className="flex items-center gap-0.5">
                        {[1, 2, 3, 4, 5].map(i => (
                          <Star key={i} size={14} className="text-amber-400 fill-amber-400" />
                        ))}
                      </div>
                      <span className="text-xs font-black text-slate-400">4.9 (120+)</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 flex items-center gap-3">
                  <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-slate-400 shadow-sm">
                    <MapPin size={18} />
                  </div>
                  <div className="overflow-hidden">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Location</p>
                    <p className="text-xs font-bold text-slate-900 truncate">{doc.hospital}</p>
                  </div>
                </div>
                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 flex items-center gap-3">
                  <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-slate-400 shadow-sm">
                    <Clock size={18} />
                  </div>
                  <div>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Availability</p>
                    <p className="text-xs font-bold text-slate-900">{doc.timings.split(' - ')[0]}</p>
                  </div>
                </div>
              </div>

              <div className="pt-6 border-t border-slate-50 flex items-center justify-between">
                <div>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-1">Consultation Fee</p>
                  <p className="text-3xl font-black text-slate-900">₹{doc.fee}</p>
                </div>
                <button 
                  onClick={() => navigate('/appointments', { state: { doctor: doc } })}
                  className="px-8 py-4 bg-slate-900 text-white rounded-2xl font-black hover:bg-emerald-600 transition-all flex items-center gap-3 shadow-xl hover:shadow-emerald-200 active:scale-95"
                >
                  Book Slot
                  <ChevronRight size={20} />
                </button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
